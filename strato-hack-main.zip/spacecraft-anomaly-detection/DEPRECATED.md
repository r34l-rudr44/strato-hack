# DEPRECATED

This folder is a duplicate of the parent folder and is no longer maintained.

**Please use the parent `stratohack/` folder instead.**

All scripts and code should be run from the parent directory:

```bash
cd ..
python scripts/download_data.py
python scripts/train.py
python scripts/evaluate.py
```

